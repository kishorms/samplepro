
1. Place the coding in below path 
c:\xampp\htdocs\projects\restaurant_smart\web

2. Opent  localhost/phpmyadmin
   Crete DB - restaurant_smart
   
3. Import restaurant_smart.sql 

4. For Project run the path in browser

localhost/projects/restaurant_smart/web/

Admin
admin@gmail.com
test

User
user@gmail.com
test

park@gmail.com
test

chef@gmail.com
test

waiter@gmail.com
test