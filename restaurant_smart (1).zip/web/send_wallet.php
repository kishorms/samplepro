<?php
/*********************
**** Arudhra Innovations *****
**** CPanel ******************
*********/

/* Following code will match admin login credentials */

//user temp array
$response = array();

// include db connect class
require_once __DIR__ . '/db_connect.php';

// connecting to db


// check for post data
$data = json_decode(file_get_contents("php://input"));
$get_email = ($data->email);
$get_product_id = ($data->product_id);

if(empty($get_email) || empty($get_product_id))
{
	$response["success"] = 2;
	echo json_encode($response);
}
else
{
	$result1 = mysql_query("SELECT * FROM login WHERE email = '$get_product_id'  ");
	$AllProducts1 = mysqli_fetch_array($result1);		
	$get_wal_bal = $AllProducts1["field_5"];

	$result = mysqli_query($conn,"SELECT * FROM bill WHERE field_1 = '$get_product_id'  ");
	$AllProducts = mysqli_fetch_array($result);		
	$get_price = $AllProducts["field_4"];
	
	if ($get_price <= $get_wal_bal )
	{
		mysql_query("UPDATE login SET field_5=field_5 + '$get_price' WHERE email = '$get_email' ");
		mysql_query("UPDATE login SET field_5=field_5 - '$get_price' WHERE email = '$get_product_id'");
		mysql_query("UPDATE bill SET field_9='Paid'  WHERE field_1 = '$get_product_id'  ");
		
		$response["success"] = 1;	
		echo json_encode($response);
	}
	else if($get_price >= $get_wal_bal )
	{
		
		$response["success"] = 2;	
		echo json_encode($response);
	}
	else
	{
		$response["success"] = 0;	
		echo json_encode($response);
	}
}
?>