var app = angular.module("myapp", ['ngCookies']);
app.controller("myappCtrl", function($scope, $cookies, $cookieStore, $http) 
{
	
/****************************************************************************/
/************************** Get Admin Details ***********************************/
/****************************************************************************/	
	$scope.cook_user_email = $cookieStore.get("cook_user_email");
	$scope.cook_staff_dept = $cookieStore.get("cook_staff_dept");
	$scope.cook_user_dept = $cookieStore.get("cook_user_dept");

	$scope.user_logout = function() 
	{
		if(confirm("Are You Sure?"))
		{
			$cookies.cook_user_email = "";
			$cookies.cook_staff_dept = "";
			window.location = "index.html";
			return;
		}
		else
		{
			return false;
		}
	}
/****************************************************************************/
/************************** Add Complaint *********************************/
/****************************************************************************/
	$scope.create_placement = function() 
	{		
	$scope.field_6="";
	$scope.field_7="";
	$scope.field_8="";
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/create_placement.php', {
		'field_1':$scope.field_1,'field_2':$scope.field_2,'field_3':$scope.field_3,
		'field_4':$scope.field_4,'field_5':$scope.field_5,'field_6':$scope.field_6,
		'field_7':$scope.field_7,'field_8':$scope.field_8,'email':$scope.cook_user_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Created Successfully");
				window.location = "view_bill.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else if(data.success == 3)
			{
				alert("Enter 10 Digit Mobile No");
			}
			else
			{
				alert("Un Successfully");
			}
        });
    }
/****************************************************************************/
/************************** Add Complaint *********************************/
/****************************************************************************/
	$scope.create_student = function() 
	{		
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/create_student.php', {
		'field_1':$scope.field_1,'field_2':$scope.field_2,'field_3':$scope.field_3,
		'field_4':$scope.field_4,'field_5':$scope.field_5,'field_6':$scope.field_6,
		'field_7':$scope.field_7,'field_8':$scope.field_8,'email':$scope.cook_user_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Student Created Successfully");
				window.location = "home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
			{
				alert("Un Successfully");
			}
        });
    }
/****************************************************************************/
/************************** admin Details *********************************/
/****************************************************************************/
	$http.post('http://10.0.2.2/projects/restaurant_smart/web/admin_get.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.admin_details = data.details;
		}
		else
		{
			$scope.admin_details = "No Data Found !!!";
		}
    });

	$http.post('http://10.0.2.2/projects/restaurant_smart/web/admin_view_all.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.all_details = data.details;
		}
		else
		{
			$scope.all_details = "No Data Found !!!";
		}
    });
/****************************************************************************/
/************************** Get Feedback *********************************/
/****************************************************************************/
	$http.post('http://10.0.2.2/projects/restaurant_smart/web/feedback_get.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.feedback_details = data.details;
		}
		else
		{
			$scope.feedback_details = "No Data Found !!!";
		}
    });
/****************************************************************************/
/************************** Get All details  *********************************/
/****************************************************************************/
	$http.post('http://10.0.2.2/projects/restaurant_smart/web/student_get.php', {'dept': $scope.cook_staff_dept})
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.details = data.details;
		}
		else
		{
			$scope.details = "No Data Found !!!";
		}
    });
	
	$http.post('http://10.0.2.2/projects/restaurant_smart/web/get_sport.php')
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.sport_details = data.details;
		}
		else
		{
			$scope.sport_details = "No Data Found !!!";
		}
    });
	
	$http.post('http://10.0.2.2/projects/restaurant_smart/web/get_booking.php')
	.success(function (response) 
	{
		$scope.booking_details = response.details;
	});
	
	
	$http.post('http://10.0.2.2/projects/restaurant_smart/web/get_placement.php')
	.success(function (response) 
	{
		$scope.bill_details = response.details;
	});
	
	
	
	$http.post('http://10.0.2.2/projects/restaurant_smart/web/get_user_booking.php', {'email': $scope.cook_user_email})
	.success(function(data, status, headers, config) 
	{
			$scope.user_booking_details = data.details;
    });
	
	$http.post('http://10.0.2.2/projects/restaurant_smart/web/get_food_order.php')
	.success(function(data, status, headers, config) 
	{
			$scope.food_order_details = data.details;
    });
	
	$http.post('http://10.0.2.2/projects/restaurant_smart/web/get_menu.php')
	.success(function (response) 
	{
		$scope.menu_details = response.details;
	});
	$http.post('http://10.0.2.2/projects/restaurant_smart/web/get_cultural.php')
	.success(function (response) 
	{
		$scope.cultural_details = response.details;
	});
	
	$http.post('http://10.0.2.2/projects/restaurant_smart/web/products_get.php')
	.success(function (response) 
	{
		$scope.mark_details = response.products;
	});
	
	
	$http.post('http://10.0.2.2/projects/restaurant_smart/web/get_user.php')
	.success(function(data, status, headers, config) 
	{
			$scope.user_details = data.details;
    });
	
/****************************************************************************/
/************************** Add Requriments *********************************/
/****************************************************************************/
	$scope.create_requirment = function() 
	{		
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/create_sport.php', {
		'field_1':$scope.field_1,'field_2':$scope.field_2,'field_3':$scope.field_3,
		'field_4':$scope.field_4,'email':$scope.cook_user_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Created Successfully");
				window.location = "home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
				{
					alert("Un Successfully");
				}
        });
    }
/****************************************************************************/
/************************** Add create_conference *********************************/
/****************************************************************************/
	$scope.create_booking = function() 
	{		
			$scope.field_3 = document.getElementById('field_3').value;
			$scope.field_2 = "Free";

		$http.post('http://10.0.2.2/projects/restaurant_smart/web/create_booking.php', {
		'field_1':$scope.field_1,'field_2':$scope.field_2,'field_3':$scope.field_3,
		'field_4':$scope.field_4,'field_5':$scope.field_5,'email':$scope.email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Created Successfully");
				window.location = "view_admin_booking.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
				{
					alert("Un Successfully");
				}
        });
    }
	
	$scope.create_booking_1 = function() 
	{		
			$scope.field_3 = document.getElementById('field_3').value;
			$scope.field_2 = "Free";

		$http.post('http://10.0.2.2/projects/restaurant_smart/web/create_booking.php', {
		'field_1':$scope.field_1,'field_2':$scope.field_2,'field_3':$scope.field_3,
		'field_4':$scope.field_4,'field_5':$scope.field_5,'email':$scope.cook_user_dept
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Created Successfully");
				window.location = "wait_home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
				{
					alert("Un Successfully");
				}
        });
    }
	
	$scope.create_booking_2 = function() 
	{		
			$scope.field_3 = document.getElementById('field_3').value;
			$scope.field_2 = "Free";

		$http.post('http://10.0.2.2/projects/restaurant_smart/web/create_booking.php', {
		'field_1':$scope.field_1,'field_2':$scope.field_2,'field_3':$scope.field_3,
		'field_4':$scope.field_4,'field_5':$scope.field_5,'email':$scope.cook_user_dept
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Created Successfully");
				window.location = "park_home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
				{
					alert("Un Successfully");
				}
        });
    }
/****************************************************************************/
/************************** Add create_conference *********************************/
/****************************************************************************/
	$scope.create_cultural = function() 
	{		
	$scope.field_3 =""
	$scope.field_4 =""
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/create_cultural.php', {
		'field_1':$scope.field_1,'field_2':$scope.field_2,'field_3':$scope.field_3,
		'field_4':$scope.field_4,'email':$scope.cook_user_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Created Successfully");
				window.location = "chef_home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
				{
					alert("Un Successfully");
				}
        });
    }
/****************************************************************************/
/************************** Add Requirment ***********************************/
/****************************************************************************/
	$http.post('http://10.0.2.2/projects/restaurant_smart/web/requirment_get.php', {'email': $scope.cook_user_email})
	.success(function(data, status, headers, config) 
	{
		if(data.success == 1)
		{
			$scope.order_details = data.details;
		}
		else
		{
			$scope.order_details = "No Data Found !!!";
		}
    });

/****************************************************************************/
/************************** Add Requriments *********************************/
/****************************************************************************/
	$scope.create_feedback = function() 
	{		
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/create_feedback.php', 
		{
		'field_1':$scope.field_1,'field_2':$scope.field_2,'email':$scope.cook_user_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Feedback Submitted Successfully");
				window.location = "user_home.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else if(data.success == 0)
			{
				alert("Error In Creating");
			}
			else
				{
					alert("Un Successfully");
				}
        });
    }

	

/****************************************************************************/
/************************** Student Update *********************************/
/****************************************************************************/
$scope.update_student = function(cus_id,field_1,field_2,field_3,
								 field_4,field_5,field_6,field_7,field_8) 
	{
		window.location = "update_student.html";
		$cookieStore.put("cook_cus_id",cus_id);
		$cookieStore.put("cook_field_1",field_1);
		$cookieStore.put("cook_field_2",field_2);
		$cookieStore.put("cook_field_3",field_3);
		$cookieStore.put("cook_field_4",field_4);
		$cookieStore.put("cook_field_5",field_5);
		$cookieStore.put("cook_field_6",field_6);
		$cookieStore.put("cook_field_7",field_7);
		$cookieStore.put("cook_field_8",field_8);
		return;
	}	
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");
	$scope.cook_field_3 = $cookieStore.get("cook_field_3");
	$scope.cook_field_4 = $cookieStore.get("cook_field_4");
	$scope.cook_field_5 = $cookieStore.get("cook_field_5");
	$scope.cook_field_6 = $cookieStore.get("cook_field_6");
	$scope.cook_field_7 = $cookieStore.get("cook_field_7");
	$scope.cook_field_8 = $cookieStore.get("cook_field_8");

	$scope.save_student = function() 
	{		
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/save_student.php',{
		'id':$scope.cook_cus_id,'field_1':$scope.cook_field_1,'field_2':$scope.cook_field_2,
		'field_3':$scope.cook_field_3,'field_4':$scope.cook_field_4,'field_5':$scope.cook_field_5,'field_6':$scope.cook_field_6,'field_7':$scope.cook_field_7,'field_8':$scope.cook_field_8})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submited successfully");
				window.location = "view_students.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }

/****************************************************************************/
/************************** Placement Update *********************************/
/****************************************************************************/
$scope.update_place = function(cus_id,field_1,field_2,field_3,
								 field_4,field_5,field_6,field_7,field_8) 
	{
		window.location = "update_placement.html";
		$cookieStore.put("cook_cus_id",cus_id);
		$cookieStore.put("cook_field_1",field_1);
		$cookieStore.put("cook_field_2",field_2);
		$cookieStore.put("cook_field_3",field_3);
		$cookieStore.put("cook_field_4",field_4);
		$cookieStore.put("cook_field_5",field_5);
		$cookieStore.put("cook_field_6",field_6);
		$cookieStore.put("cook_field_7",field_7);
		$cookieStore.put("cook_field_8",field_8);
		return;
	}	
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");
	$scope.cook_field_3 = $cookieStore.get("cook_field_3");
	$scope.cook_field_4 = $cookieStore.get("cook_field_4");
	$scope.cook_field_5 = $cookieStore.get("cook_field_5");
	$scope.cook_field_6 = $cookieStore.get("cook_field_6");
	$scope.cook_field_7 = $cookieStore.get("cook_field_7");
	$scope.cook_field_8 = $cookieStore.get("cook_field_8");

	$scope.save_placement = function() 
	{		
	$scope.cook_field_6="";
	$scope.cook_field_7="";
	$scope.cook_field_8="";
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/save_placement.php',{
		'id':$scope.cook_cus_id,'field_1':$scope.cook_field_1,'field_2':$scope.cook_field_2,
		'field_3':$scope.cook_field_3,'field_4':$scope.cook_field_4,
		'field_5':$scope.cook_field_5,'field_6':$scope.cook_field_6,
		'field_7':$scope.cook_field_7,'field_8':$scope.cook_field_8})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submited successfully");
				window.location = "view_bill.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }


/****************************************************************************/
/************************** Sport Update *********************************/
/****************************************************************************/
$scope.update_sport = function(cus_id,field_1,field_2,field_3,
								 field_4,field_5,field_6,field_7,field_8) 
	{
		window.location = "update_sport.html";
		$cookieStore.put("cook_cus_id",cus_id);
		$cookieStore.put("cook_field_1",field_1);
		$cookieStore.put("cook_field_2",field_2);
		$cookieStore.put("cook_field_3",field_3);
		$cookieStore.put("cook_field_4",field_4);
		return;
	}	
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");
	$scope.cook_field_3 = $cookieStore.get("cook_field_3");
	$scope.cook_field_4 = $cookieStore.get("cook_field_4");

	$scope.save_sport = function() 
	{		
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/save_sport.php',{
		'id':$scope.cook_cus_id,'field_1':$scope.cook_field_1,'field_2':$scope.cook_field_2,
		'field_3':$scope.cook_field_3,'field_4':$scope.cook_field_4})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Update successfully");
				window.location = "view_sports.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }

	
	
/****************************************************************************/
/************************** Cultural Update *********************************/
/****************************************************************************/
$scope.update_culture = function(cus_id,field_1,field_2,field_3,
								 field_4,field_5,field_6,field_7,field_8) 
	{
		window.location = "update_cultural.html";
		$cookieStore.put("cook_cus_id",cus_id);
		$cookieStore.put("cook_field_1",field_1);
		$cookieStore.put("cook_field_2",field_2);
		$cookieStore.put("cook_field_3",field_3);
		$cookieStore.put("cook_field_4",field_4);
		return;
	}	
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");
	$scope.cook_field_3 = $cookieStore.get("cook_field_3");
	$scope.cook_field_4 = $cookieStore.get("cook_field_4");

	$scope.save_cultural = function() 
	{		
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/save_cultural.php',{
		'id':$scope.cook_cus_id,'field_1':$scope.cook_field_1,'field_2':$scope.cook_field_2,
		'field_3':$scope.cook_field_3,'field_4':$scope.cook_field_4})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Update successfully");
				window.location = "view_cultural.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }

	
	
/****************************************************************************/
/************************** Conference Update *********************************/
/****************************************************************************/
$scope.update_conference = function(cus_id,field_1,field_2,field_3,
								 field_4,field_5) 
	{
		window.location = "update_conference.html";
		$cookieStore.put("cook_cus_id",cus_id);
		$cookieStore.put("cook_field_1",field_1);
		$cookieStore.put("cook_field_2",field_2);
		$cookieStore.put("cook_field_3",field_3);
		$cookieStore.put("cook_field_4",field_4);
		$cookieStore.put("cook_field_5",field_5);
		return;
	}	
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_field_1 = $cookieStore.get("cook_field_1");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");
	$scope.cook_field_3 = $cookieStore.get("cook_field_3");
	$scope.cook_field_4 = $cookieStore.get("cook_field_4");
	$scope.cook_field_5 = $cookieStore.get("cook_field_5");

	$scope.save_conference = function() 
	{		
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/save_conference.php',{
		'id':$scope.cook_cus_id,'field_1':$scope.cook_field_1,'field_2':$scope.cook_field_2,
		'field_3':$scope.cook_field_3,'field_4':$scope.cook_field_4,'field_5':$scope.cook_field_5})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Update successfully");
				window.location = "view_conference.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }

	
	
/****************************************************************************/
/************************** User Update *********************************/
/****************************************************************************/
	
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/get_user_info.php',
		{
			'email':$scope.cook_user_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{			
				$scope.userdetails = data.details;
			}
          });
		  
$scope.user_update_info = function(name,password,mobile) 
	{
		window.location = "user_info_edit.html";
		$cookieStore.put("cook_name",name);
		$cookieStore.put("cook_password",password);
		$cookieStore.put("cook_mobile",mobile);
		return;
	}	
	
	$scope.cook_name = $cookieStore.get("cook_name");
	$scope.cook_password = $cookieStore.get("cook_password");
	$scope.cook_mobile = $cookieStore.get("cook_mobile");

	$scope.save_update_info = function() 
	{		
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/user_update_info.php',{
		 'name':$scope.cook_name, 'password':$scope.cook_password,
		 'mobile': $scope.cook_mobile, 'email': $scope.cook_user_email})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Submited successfully");
				window.location = "user_update_info.html";
				return;				
			}
			else
			{
				alert("Invalid Inputs");
			}   
          });
     }
	 
	 /****************************************************************************/
/************************** Delete Disaster *********************************/
/****************************************************************************/
	// products_delete
	$scope.img_delete = function(cus_id) 
	{		
        $http.post('http://10.0.2.2/projects/restaurant_smart/web/img_delete.php', 
		{
		'cus_id': cus_id
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Deleted Successful");
				window.location = "home.html";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting Product!!");
			}
			else
			{
				alert("No id found");
			}
        });
    }
	
	
	$scope.book_now = function(cus_id) 
	{		
        $http.post('http://10.0.2.2/projects/restaurant_smart/web/book_now.php', 
		{
		'cus_id': cus_id
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Updated Successful");
				 location.reload(); 
				//window.location = "view_admin_booking.html";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting Product!!");
			}
			else
			{
				alert("No id found");
			}
        });
    }
	
	$scope.free_now = function(cus_id) 
	{		
        $http.post('http://10.0.2.2/projects/restaurant_smart/web/free_now.php', 
		{
		'cus_id': cus_id
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Updated Successful");
				 location.reload(); 
				//window.location = "view_admin_booking.html";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting Product!!");
			}
			else
			{
				alert("No id found");
			}
        });
    }
	
	$scope.delete_book = function(cus_id) 
	{		
        $http.post('http://10.0.2.2/projects/restaurant_smart/web/delete_book.php', 
		{
		'cus_id': cus_id
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Deleted Successful");
				window.location = "view_admin_booking.html";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting Product!!");
			}
			else
			{
				alert("No id found");
			}
        });
    }
	
	$scope.food_order_status = function(cus_id) 
	{		
        $http.post('http://10.0.2.2/projects/restaurant_smart/web/food_order_status.php', 
		{
		'cus_id': cus_id
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Updated Successful");
				window.location = "view_chef_booking.html";
				return;
			}
			else if(data.success == 0)
			{
				alert("Error While Deleting Product!!");
			}
			else
			{
				alert("No id found");
			}
        });
    }
	/*****************************************************************************/
/************************** Update Gallery File Cookie*********************************/
/****************************************************************************/
	$scope.img_update = function(cus_id) 
	{
		
		$cookieStore.put("cook_cus_id",cus_id);
		window.location = "edit_file.html";
		return;
	}
	

	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	
	$scope.book_slot = function(cus_id,field_5) 
	{
		
		$cookieStore.put("cook_cus_id",cus_id);
		$cookieStore.put("cook_field_5",field_5);
		window.location = "post_booking.html";
		return;
	}
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_field_5 = $cookieStore.get("cook_field_5");
	
	$scope.update_booking = function() 
	{		
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/save_booking.php', {
		'field_1':$scope.field_1,'field_2':$scope.field_2,'field_3':$scope.field_3,
		'field_4':$scope.cook_field_5,'id':$scope.cook_cus_id,'email':$scope.cook_user_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Booked Successfully");
				window.location = "view_user_booking.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
			{
				alert("Un Successfully");
			}
        });
    }

	$scope.food_order = function(cus_id,field_2) 
	{
		
		$cookieStore.put("cook_cus_id",cus_id);
		$cookieStore.put("cook_field_2",field_2);
		window.location = "post_food_order.html";
		return;
	}
	
	$scope.cook_cus_id = $cookieStore.get("cook_cus_id");
	$scope.cook_field_2 = $cookieStore.get("cook_field_2");

	
	$scope.save_food_order = function() 
	{		
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/save_food_order.php', {
		'field_1':$scope.cook_field_2,'field_2':$scope.field_1,'field_3':$scope.field_2,
		'email':$scope.cook_user_email
		})
		.success(function(data, status, headers, config) 
		{
			if(data.success == 1)
			{
				alert("Booked Successfully");
				window.location = "view_activity_booking.html";
				return;				
			}
			else if(data.success == 2)
			{
				alert("Please Fill All Fields");
			}
			else
			{
				alert("Un Successfully");
			}
        });
    }
	
	$scope.send_wallet= function(field_1) 
	{
		$http.post('http://10.0.2.2/projects/restaurant_smart/web/send_wallet.php',{
			'product_id': field_1,'email':$scope.cook_user_email})	
		.success(function(data, status, headers, config)
		{
			if(data.success == 1)
			{
				alert("Wallet Payment successful");
				window.location = "view_bill.html";
				return;
			}
			else if(data.success == 2)
			{
				alert("Low Wallet Balance");
			}
			else
			{
				alert("Added successful");
				window.location = "order.html";
				return;
			}
		});
	}
		


	
});